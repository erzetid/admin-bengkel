// Copyright (c) 2022 fahrizalm14
//
// This software is released under the MIT License.
// https://opensource.org/licenses/MIT

export { Customer } from "./Customer";
export { Vehicle } from "./Vehicle";
